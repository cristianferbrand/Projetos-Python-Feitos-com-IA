# dashboard_flet.py (patched shim for Colors/Icons)
import os
import flet as ft
import requests

API_URL = os.getenv("API_URL", "http://127.0.0.1:8000").rstrip("/")
REFRESH_SECONDS = int(os.getenv("REFRESH_SECONDS", "5"))

# === Shim robusto p/ ft.Colors/ft.colors e ft.Icons/ft.icons (sem avaliar atributo inexistente) ===
C = ft.__dict__.get("Colors") or ft.__dict__.get("colors")
I = ft.__dict__.get("Icons") or ft.__dict__.get("icons")

# Fallback seguro caso não exista (muito improvável, mas evita crashes)
if C is None:
    class _C:
        pass
    C = _C()

if I is None:
    class _I:
        COMPUTER = "computer"
        OPEN_IN_NEW = "open_in_new"
        DASHBOARD = "dashboard"
    I = _I()

# Cores com fallback (mantém UI mesmo que constants não existam)
PRIMARY = getattr(C, "PRIMARY", "#1E88E5")
SECONDARY = getattr(C, "SECONDARY", "#8AB4F8")
GREEN = getattr(C, "GREEN", "#00C853")
GREY = getattr(C, "GREY", "#9E9E9E")
ON_SURFACE_VARIANT = getattr(C, "ON_SURFACE_VARIANT", "#9AA0A6")
SURFACE = getattr(C, "SURFACE", "#202124")

def op(alpha: float, color: str):
    # tenta Colors.with_opacity (0.24+) ou colors.with_opacity (antigo)
    try:
        return getattr(ft.Colors, "with_opacity")(color, alpha)
    except Exception:
        try:
            return getattr(ft, "colors").with_opacity(color, alpha)
        except Exception:
            return color

class DeviceCard(ft.Card):
    def __init__(self, device: dict, on_open):
        super().__init__()
        online = device.get("online", False)
        self.content = ft.Container(
            padding=16,
            content=ft.Row(
                [
                    ft.Icon(getattr(I, "COMPUTER", "computer"), color=GREEN if online else GREY),
                    ft.Column(
                        [
                            ft.Text(device["name"], weight=ft.FontWeight.BOLD),
                            ft.Text(
                                f"Janela: {device.get('current_window','—')}\nProc.: {device.get('current_process','—')}",
                                size=12,
                                color=ON_SURFACE_VARIANT,
                            ),
                            ft.Text(
                                f"Último contato: {device.get('last_seen','—')}", size=11, color=SECONDARY
                            ),
                        ],
                        expand=True,
                    ),
                    ft.IconButton(getattr(I, "OPEN_IN_NEW", "open_in_new"), tooltip="Abrir detalhes", on_click=lambda e: on_open(device)),
                ]
            ),
        )

class Dashboard(ft.UserControl):
    def build(self):
        self.devices_col = ft.Column(scroll=ft.ScrollMode.AUTO, expand=True)
        self.detail = ft.Container(padding=16, expand=True)

        self.page_banner = ft.Row(
            [
                ft.Icon(getattr(I, "DASHBOARD", "dashboard")),
                ft.Text("Monitor de Produtividade", size=20, weight=ft.FontWeight.BOLD),
                ft.Container(expand=True),
                ft.TextButton("Atualizar", on_click=lambda e: self.refresh()),
            ]
        )
        return ft.Row([
            ft.Container(width=420, content=ft.Column([self.page_banner, self.devices_col], expand=True)),
            ft.VerticalDivider(),
            ft.Container(expand=True, content=self.detail),
        ], expand=True)

    def did_mount(self):
        self.refresh()
        self.page.run_task(self.auto_refresh)

    async def auto_refresh(self):
        while True:
            await self.page.sleep(REFRESH_SECONDS)
            self.refresh()

    def refresh(self):
        try:
            r = requests.get(f"{API_URL}/api/devices", timeout=10)
            data = r.json()
        except Exception:
            data = {"devices": []}
        self.devices_col.controls = [
            DeviceCard(d, on_open=self.open_detail) for d in data.get("devices", [])
        ]
        self.update()

    def open_detail(self, device: dict):
        # painel direito: última captura + top apps do dia
        last_url = None
        created_at = "—"
        top = []
        try:
            r = requests.get(f"{API_URL}/api/device/{device['id']}/last_screenshot", timeout=10)
            j = r.json()
            last_url = j.get("url")
            created_at = j.get("created_at", "—")
        except Exception:
            pass
        try:
            r2 = requests.get(f"{API_URL}/api/device/{device['id']}/summary/today", timeout=10)
            top = r2.json().get("top_process_minutes", [])
        except Exception:
            pass

        kpis = ft.Row([
            ft.Container(
                bgcolor=op(0.08, PRIMARY), padding=12, border_radius=12,
                content=ft.Column([
                    ft.Text("Status", size=12, color=SECONDARY),
                    ft.Text("ONLINE" if device.get("online") else "OFFLINE", size=18, weight=ft.FontWeight.BOLD),
                ]),
            ),
            ft.Container(
                bgcolor=op(0.08, PRIMARY), padding=12, border_radius=12,
                content=ft.Column([
                    ft.Text("Janela atual", size=12, color=SECONDARY),
                    ft.Text(device.get("current_window", "—"), max_lines=2),
                ]),
            ),
        ])

        top_table = ft.DataTable(
            columns=[
                ft.DataColumn(ft.Text("Processo")),
                ft.DataColumn(ft.Text("Minutos (hoje)")),
            ],
            rows=[ft.DataRow(cells=[ft.DataCell(ft.Text(t["process_name"])), ft.DataCell(ft.Text(str(t["minutes"])))]) for t in top],
        )

        img = ft.Image(src=f"{API_URL}{last_url}" if last_url else None, fit=ft.ImageFit.CONTAIN, height=420)

        self.detail.content = ft.Column([
            ft.Row([ft.Text(device["name"], size=18, weight=ft.FontWeight.BOLD)]),
            kpis,
            ft.Text(f"Última captura: {created_at}", size=12, color=SECONDARY),
            ft.Container(img, border_radius=12, bgcolor=op(0.04, SURFACE)),
            ft.Text("Top aplicativos (hoje)", weight=ft.FontWeight.BOLD),
            top_table,
        ], scroll=ft.ScrollMode.AUTO)
        self.detail.update()

def main(page: ft.Page):
    page.title = "Painel de Produtividade"
    page.theme_mode = ft.ThemeMode.DARK
    page.padding = 12
    page.add(Dashboard())

if __name__ == "__main__":
    ft.app(target=main)
